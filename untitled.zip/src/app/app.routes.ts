import { Routes } from '@angular/router';
import {SvgEditorComponent} from './svg-editor/svg-editor.component';

export const routes: Routes = [
  { path: '', component: SvgEditorComponent }
];
